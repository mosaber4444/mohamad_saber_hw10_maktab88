let getName = $('#getName');
let getLastName = $('#getLastName');
let getEmail = $('#getEmail');
let getPass = $('#getPass');

function validateEmail(email) {
    let re = /\S+@\S+\.\S+/;
    return re.test(email);
}

function validatePass(pass) {
    let re = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
    return re.test(pass);
}

function validateName(name) {
    let re = /^[a-z]{0,30}$/
    return re.test(name);
}

function validation() {

    if (!validateName(getName.val())) {
        alert('name not valid');
        return;
    }

    if (!validateName(getLastName.val())) {
        alert('last name not valid');
        return;
    }

    if (!validateEmail(getEmail.val())) {
        alert('email not valid');
        return;
    }

    if (!validatePass(getPass.val())) {
        alert('password not valid');
        return;
    }

    alert('regster is ok');
    getPass.empty()
    getLastName.empty()
    getName.empty()
    getEmail.empty()
}

