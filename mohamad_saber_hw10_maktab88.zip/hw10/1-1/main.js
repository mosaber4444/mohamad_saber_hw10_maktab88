let getURL = $('#getURL')
let getOperator = $('#getOperator')
let resText = $('#text1')
let reqText = $('#text2')

function operator() {
    $(() => {
        $.ajax({
            url: getURL.val(),
            type: getOperator.val(),
            success: function (res) {
                if (getOperator.val() === 'get') {
                    resText.val(JSON.stringify(res));
                    reqText.val('');
                } else if (getOperator.val() === 'post') {
                    reqText.val(JSON.stringify(res));
                    resText.val('')
                }
            },
        });
    });
}

