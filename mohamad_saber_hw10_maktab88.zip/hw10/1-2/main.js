

let a = $.ajax({
    url: 'https://reqres.in/api/users?page=1',
    type: 'get',
    success: function (response) {
        console.log(response)
    }
});

console.log(a['page'])